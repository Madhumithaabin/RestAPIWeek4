package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="./src/test/java/features/CreateIssue.feature",glue= {"hooks","steps"},monochrome=true)
public class JiraRunner extends AbstractTestNGCucumberTests{

	
	
}
