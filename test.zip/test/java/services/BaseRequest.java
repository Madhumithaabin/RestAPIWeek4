package services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class BaseRequest {
	
	public static RequestSpecification reqspecific;
	@BeforeMethod
	public void init() throws FileNotFoundException, IOException {
		
		Properties prop = new Properties();
		prop.load(new FileInputStream(new File("./src/test/resources/jiraconfig.properties")));
		String server = prop.getProperty("server");
	String resource = prop.getProperty("resources");
	String username = prop.getProperty("username");
	String password = prop.getProperty("password");
	RestAssured.baseURI=server+"/"+resource;
	RestAssured.authentication=RestAssured.preemptive().basic(username, password);
	reqspecific=RestAssured.given().log().all();
	}
	
	@AfterMethod
	public void teardown() {
		
	}

}
