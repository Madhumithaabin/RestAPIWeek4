package services;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IssueTests extends BaseRequest {

	@Test
	public void createIssue() {
		File filename=new File("./src/test/resources/Data/data1.json");

		reqspecific
		.when()
		.contentType(ContentType.JSON)
		.body(filename).post()
		.then()
		.assertThat()
		.statusCode(201);
	
	}
	
}
