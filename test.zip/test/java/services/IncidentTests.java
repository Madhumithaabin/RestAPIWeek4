package services;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import static org.hamcrest.Matchers.containsString;

public class IncidentTests extends BaseRequests{
	
	
	@Test
	public void getIncidents() {
		
		reqSpec
			.when()
			.contentType(ContentType.JSON)
			.body("{\"short_description\" : \"This is Makaia\"}")
			.post("incident")
			.then()
			.assertThat()
			.statusCode(201)
			.body(containsString("number"), containsString("sys_id"));
			
	}

}
