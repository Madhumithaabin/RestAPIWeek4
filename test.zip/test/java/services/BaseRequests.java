package services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class BaseRequests {
	
	public static RequestSpecification reqSpec;
	
	@BeforeMethod
	public void init() throws FileNotFoundException, IOException {
		
		Properties prop = new Properties();
		prop.load(new FileInputStream(new File("./src/test/resources/config.properties")));
		
		String server = prop.getProperty("server");
		String resources = prop.getProperty("resources");

		String username = prop.getProperty("username");
		String password = prop.getProperty("password");

		
		RestAssured.baseURI = server+"/"+resources;
		RestAssured.authentication = RestAssured.basic(username, password);
		
		reqSpec = RestAssured.given().log().all();
		
	}
	
	@AfterMethod
	public void tearDown() {
		
	}

}
