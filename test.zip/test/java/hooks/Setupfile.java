package hooks;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.zone.ZoneRulesException;
import java.util.Properties;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.restassured.RestAssured;

public class Setupfile {

	@Before
	public void init() throws FileNotFoundException, IOException {
		
		Properties prop = new Properties();
		prop.load(new FileInputStream(new File("./src/test/resources/jiraconfig.properties")));
		String server = prop.getProperty("server");
	String resource = prop.getProperty("resources");
	String username = prop.getProperty("username");
	String password = prop.getProperty("password");
	System.out.println(server);
	System.out.println(resource);
	String uri=server+"/"+resource;
	System.out.println(uri);
	RestAssured.authentication=RestAssured.basic(username, password);
	//RestAssured.authentication=RestAssured.preemptive().basic(username, password);
	}
	
	@After
	public void teardown() {
		
	}
}
