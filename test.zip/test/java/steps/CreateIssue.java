package steps;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CreateIssue extends BaseAPIFile{


@Given("Enable logs")
public void enable_logs() {
    // Write code here that turns the phrase above into concrete actions
reqspecific= reqspecific.log().all();
}

@Given("Add bodydata from data1.json file")
public void add_bodydata_from_data1_json_file() {
    // Write code here that turns the phrase above into concrete actions
	File filename=new File("./src/test/resources/Data/data1.json");
 reqspecific=reqspecific.when().contentType(ContentType.JSON).body(filename);
}

@When("issue is created")
public void issue_is_created() {
    // Write code here that turns the phrase above into concrete actions
response = reqspecific.post();
response.prettyPrint();
}

@Then("verify the statuscode as {int}")
public void verify_the_statuscode_as(Integer statuscode) {
    // Write code here that turns the phrase above into concrete actions
  validateresponse=response.then().statusCode(statuscode);
  
}



}
