package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class IncidentSteps extends BaseAPI{
	
	/*
	  	Given Enable logs
		And Add short description to the incident
		When Incident is created
		Then Verify the status code is 201
		And Verify the response includes the following

	 */

	@Given("Enable logs")
	public void enableLogs() {
		reqSpec = reqSpec.log().all();
	}
	
	@And("Add short description to the incident as (.*)$")
	public void addShortDescription(String shortDesc) {
		reqSpec = reqSpec.when().contentType(ContentType.JSON)
		.body("{\"short_description\" : \""+shortDesc+"\"}");
	}
	
	@When("Incident is created")
	public void createIncident() {
		response = reqSpec.post("incident");
		response.prettyPrint();
	}
	
	
	@Then("Verify the status code is (\\d+)$")
	public void verifyStatus(int code) {
		responseJson = response.then().statusCode(code);
	}
	
	@And("Verify the response$")
	public void verifyResponseContents() {
	
		//response.then().b
		
	}
}
