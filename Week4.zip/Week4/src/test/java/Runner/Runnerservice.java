package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="C:\\Users\\Cyril El Rey\\eclipse-workspace\\Week4\\src\\test\\java\\Feature\\Changerequest.feature",glue="StepDefinition",monochrome=true,publish =true)
public class Runnerservice extends AbstractTestNGCucumberTests{

}
