package Assignment_Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="./src/test/java/Assignment_Feature/CreateChange.feature",glue="Assignment_StepDefinition",publish=true,monochrome=true)
public class Servicenowrunner extends AbstractTestNGCucumberTests{

}
