package Assignment_Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="./src/test/java/Assignment_Feature/CreateChangeReq.feature",glue="StepdefinitionQ2",publish=true,monochrome=true)
public class ServicenowRunnerQ2 extends AbstractTestNGCucumberTests{

}
