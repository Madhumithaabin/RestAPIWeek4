package StepdefinitionQ2;

import org.hamcrest.Matchers;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Assignment2StepDefinition{
	public static RequestSpecification inputReq;
	public static Response response;
	public static String sys_id;
	public static ValidatableResponse validatebleresponse;
	public static ValidatableResponse validatebleres;
	
	@Given("setup the baseuri")
	public void setup_the_baseuri() {
	    // Write code here that turns the phrase above into concrete actions
	RestAssured.baseURI="https://dev65704.service-now.com/api/now/table/change_request";
	}
	@Given("setup the authentication with valid credentials")
	public void setup_the_authentication_with_valid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
	    RestAssured.authentication=RestAssured.basic("admin", "sRs5uA7Ar*F^");
}
	
	@Given("pass the bodydata using {string} and {string} details")
	public void pass_the_bodydata_using_description_and_jsonfile(String descrip,String category) {
	    // Write code here that turns the phrase above into concrete actions
		String bodydata="{\"description\":\""+descrip+"\",\"category\":\""+category+"\"}";
		inputReq = RestAssured.given().log().all()
				.contentType(ContentType.JSON)
				.queryParam("sysparm_fields", "sys_id,category,number,description")
				.body(bodydata);

	
	}
	@When("place the post request with the tablename {string}")
	public void place_the_post_request_with_the_tablename(String tablename) {
	    // Write code here that turns the phrase above into concrete actions
		response = inputReq.post();
	}

	@Then("verify the response body contains details as {string}")
	public void verify_the_response_body_as(String description) {
	    // Write code here that turns the phrase above into concrete actions
		validatebleresponse = response.then();
		validatebleresponse.assertThat().body("result.description",Matchers.equalTo(description));
			sys_id= response.jsonPath().get("result.sys_id");
		System.out.println("Change Request Number: "+sys_id);
	validatebleresponse.log().all();
}

@Given("pass the bodydata with description as {string}")
public void pass_the_bodydata_with_description_as_test(String description) {
    // Write code here that turns the phrase above into concrete actions
	String bodydata1="{\"description\":\""+description+"\"}";
	
	inputReq = RestAssured.given().log().all()
			.contentType(ContentType.JSON)
			.queryParam("sysparm_fields", "sys_id,number,category,description")
			.body(bodydata1);
	System.out.println("Change Request Number for put Request: "+sys_id);

}
@When("place the put request with the tablename {string} and change request number")
public void place_the_put_request_with_the_tablename_and_change_request_number(String tablename) {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("Change Request Number for put Request: "+sys_id);

	validatebleres=inputReq.when().put(sys_id).then();
}
@Then("verify the status code as '{int}' and content type")
public void verify_the_status_code_as_and_content_type(Integer statuscode) {
    // Write code here that turns the phrase above into concrete actions
	validatebleres.assertThat().statusCode(statuscode).contentType(ContentType.JSON);

}
@When("place the delete request with system id")
public void place_the_delete_request_with_system_id() {
    // Write code here that turns the phrase above into concrete actions
  response= RestAssured.delete(sys_id);
}
@Then("verify the status code as '{int}'")
public void verify_the_status_code_as(Integer statuscode) {
    // Write code here that turns the phrase above into concrete actions
response.then().assertThat().statusCode(statuscode);    
}

}
