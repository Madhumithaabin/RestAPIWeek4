package StepDefinition;

import java.io.File;
import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Getallincidents {
	public static Response response;
	public static RequestSpecification requestspecific;
	@Given("setup the base URI")
	public void setup_the_base_uri() {
	    // Write code here that turns the phrase above into concrete actions

		RestAssured.baseURI="https://dev81794.service-now.com/api/now/table/incident";

	}
	@Given("setup the authentication with valid credentials")
	public void setup_the_authentication_with_valid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
		
RestAssured.authentication=RestAssured.basic("admin", "R3Vfb!jLt1-Z");
		
	}
	@When("place the get request")
	public void place_the_get_request() {
	    // Write code here that turns the phrase above into concrete actions
	response=RestAssured.given().log().all().get();
		
	}
	@Then("valid the status code is {int}")
	public void valid_the_status_code_is(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
		int code=response.getStatusCode();
		response.then().assertThat().statusCode(int1);
		System.out.println(code);
		response.prettyPrint();
	    
	}
	@Given("pass the bodydata from {string} file")
	public void pass_the_bodydata_from_data_json_file(String filen) {
	File filename=new File("./src/test/java/data/"+filen);	
	requestspecific = RestAssured
			.given()
			.log()
			.all()
			.contentType(ContentType.JSON)
			.body(filename);
	}
	@When("place the post request")
	public void place_the_post_request() {
	response=requestspecific.post();
	}

}
