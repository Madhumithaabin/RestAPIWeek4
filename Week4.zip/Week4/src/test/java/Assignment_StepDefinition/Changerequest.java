package Assignment_StepDefinition;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class Changerequest {

	public static RequestSpecification inputReq;
	public static Response response;
	
@Given("setup the baseuri")
public void setup_the_baseuri() {
    // Write code here that turns the phrase above into concrete actions
RestAssured.baseURI="https://dev65704.service-now.com/api/now/table/";  
}
@Given("setup the authentication with valid credentials")
public void setup_the_authentication_with_valid_credentials() {
    // Write code here that turns the phrase above into concrete actions
    RestAssured.authentication=RestAssured.basic("admin", "sRs5uA7Ar*F^");
}

@Given("pass the bodydata using {string} jsonfile")
public void pass_the_bodydata_using_data1_json_jsonfile(String jsonfilename) {
    // Write code here that turns the phrase above into concrete actions
	System.out.print(jsonfilename);
	

	File filename=new File("./src/test/resources/Data/"+jsonfilename);
	System.out.print(filename);
	inputReq = RestAssured.given().log().all()
			.contentType(ContentType.JSON)
			.queryParam("number", "description,category")
			.body(filename);

}

@When("place the post request with the tablename {string}")
public void place_the_post_request_with_the_tablename(String tablename) {
    // Write code here that turns the phrase above into concrete actions
    response = inputReq.post(tablename);
}
@Then("verify the status code as'{int}'")
public void verify_the_status_code_as(Integer statuscode) {
    // Write code here that turns the phrase above into concrete actions
  ValidatableResponse validatebleresponse = response.then();
	validatebleresponse.assertThat().statusCode(statuscode);
validatebleresponse.log().all();
}


}
